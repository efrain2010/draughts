
public class DraughtsTest {

    public static void main(String[] args) {

        new Controller(new Model());

    }

}